import React from 'react'
import { Nav } from '../components/nav'
import Search from '../components/search'
export default function File() {
    return (
        <div>
           <Nav />
           <Search />
        </div>
    )
}
