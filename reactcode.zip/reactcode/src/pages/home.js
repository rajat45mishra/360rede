import React from 'react'
import Sidebar from '../components/sidebar'
import { Nav } from '../components/nav'
import Demo from '../components/cropper'
import Form from '../components/form'
import SimpleDialog from '../components/popupfor'
import useCameraId from '../hooks/useCameraId'
import ISOIcon from '../iso.svg'
import shuttIcon from '../shutt.svg'
import useProject from '../hooks/useProject'


const daforfa={
	method: 'GET',
	headers: {
	  'Content-Type': 'application/json'
	}
  };

async function CameraAutoD(url) {
    return fetch(url,daforfa);
   }
async function CameraAutoDP(url,config) {
    return fetch(url,{
            method: 'POST',
            headers: {
              'Content-Type': 'application/json'
            },
            body:JSON.stringify(config)
          }
        ).then(data => data.json())
   }

export function Home() {
    const [open, setOpen] = React.useState(false);
    const {cameraid, setCameraId} = useCameraId();
const [ConfigTo, setConfigTo] = React.useState();
const [photo, setphoto] = React.useState(false);
const {project,setProject}=useProject();
const [mess,setMess]=React.useState();

    const handleClickOpen = () => {
        setOpen(true);
      };
      const handleClose = () => {
        setOpen(false);
      };
let buttons_vg=['image capture done clickon video button','SnapShot Captured','video created goto filemanager or create new Project.'];
    const selectedValue=55;
      const handleCapture = async e => {
		const urlgj='http://0.0.0.0:5000/camera_ctrl/api/camera_capture_img_and_download/'+cameraid+'/'+project["name"];
		const toke = await CameraAutoD(urlgj);
        setMess(buttons_vg[1]);
        handleClickOpen();
	  }
      const handleConfig = async e => {
		const urlgj='http://0.0.0.0:5000/camera_ctrl/api/CameraConfigForApi/'+cameraid;
		const toke = await CameraAutoDP(urlgj,ConfigTo);
	  }
      const handleStart = async e => {
        let data={
            "project":{"name":project["name"],"time":project["time"],"created_by":project["created_by"]}
        }
		const urlgj='http://0.0.0.0:5000/camera_ctrl/api/Start/'+cameraid;
		const datafordone = await CameraAutoDP(urlgj,data);
        console.log(datafordone);
        if (datafordone){
            console.log("hi its da"+datafordone);
            setphoto(true);
            handleClickOpen();
            setMess(buttons_vg[0]);
            
        };
	  }
      const handlevideo=async e=>{
        let data={
            "project":{"name":project["name"],"time":project["time"],"created_by":project["created_by"]}
        }
        
            const urlgjk='http://0.0.0.0:5000/camera_ctrl/api/VideoProcess';
            const datafordone = await CameraAutoDP(urlgjk,data);
            console.log(datafordone);
            setMess(buttons_vg[2]);
            handleClickOpen();
    }
      React.useEffect(() => {
       
        if(ConfigTo){
            handleConfig();
        };
        console.log(photo);        
    })
    function oprions(texty) {
        const data = localStorage.getItem("congfigdata");
        const iso=JSON.parse(data);
        let isodata=iso
        return isodata[texty]
        }
    const iso=oprions("iso")
    const shutterspeed=oprions("shutterspeed")
    console.log(shutterspeed)
    const colortemperature=oprions("colortemperature")
    const aperture=oprions("aperture")
    const whitebalance=oprions("whitebalance")


    return (
        <div>
            <Nav />
            <Sidebar />
            <div style={{ marginLeft: 200, marginTop: 40 }}>
                <div style={{ display: 'flex' }}>
                    <Demo />
                    <div style={{ justifyContent: 'space-between', flex: 1, marginLeft: 400 }}>
                        <div style={{ width: '90%', padding: 13 }}><img src={ISOIcon} style={{width:35,height:35}}></img>  ISO:<br></br>
                            <Form options={iso} setSeconds={setConfigTo} title="ISO" />
                        </div>
                        <div style={{ width: '90%', padding: 13 }} ><img src={shuttIcon} style={{width:35,height:35}}/> Shutterspeed:<br></br>
                            <Form options={shutterspeed} setSeconds={setConfigTo} title="shutterspeed"/>
                        </div>
                        <div style={{ width: '90%', padding: 13 }} ><i class="fas fa-temperature-low fa-2x"></i> Aperture:<br></br>
                            <Form options={aperture} setSeconds={setConfigTo} title="aperture"/>
                        </div>
                        <div style={{ width: '90%', padding: 13 }} ><i class="fa fa-balance-scale fa-2x"></i> Whitebalance:<br></br>
                            <Form options={whitebalance} setSeconds={setConfigTo} title="whitebalance"/>
                        </div>
                        <div style={{ width: '90%', padding: 13 }} ><i class="fas fa-cloud fa-2x"></i>  Colortemperature:<br></br>
                            <Form options={colortemperature} setSeconds={setConfigTo} title="colortemperature" />
                        </div>
                    </div>
                </div>
                <div style={{ padding: '4%', display: 'flex', width: '50%' }}>
                    <button id="start" className="waves-effect waves-light btn-large" type="submit"  style={{backgroundColor:'#039be5'}}onClick={handleStart}><i class="fa fa-play-circle"></i></button>
                    <button id="snap" className="waves-effect waves-light btn-large" type="submit" style={{ marginLeft: '20%',backgroundColor:'#039be5' }} onClick={handleCapture}><i class="fas fa-camera fa-5x"></i></button>
                    <button id="video" className="waves-effect waves-light btn-large" type="submit" style={{ marginLeft: '20%',backgroundColor:'#039be5' }} onClick={handlevideo}><i class="fas fa-video"></i></button>
                </div>
                <SimpleDialog selectedValue={selectedValue} open={open} onClose={handleClose} mess={mess} />
            </div>
        </div>
    )
}
