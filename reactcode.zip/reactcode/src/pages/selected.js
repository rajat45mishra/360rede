import React from 'react'
import Selectedthumbnail from '../components/selectedthumbnail'
import { Nav } from '../components/nav'

export default function Selected() {
    return (
        <div>
            <Nav />
           <Selectedthumbnail /> 
        </div>
    )
}
