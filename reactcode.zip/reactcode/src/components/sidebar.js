import React,{ useState} from 'react'
import useProject from '../hooks/useProject'
import $ from 'jquery'

 async function motor(credentials,end) {
   let url='http://0.0.0.0:5000/api/'+end
  return fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(credentials)
  })
    .then(data => data.json())
 }
export default function Sidebar() {
    const {project,setProject}=useProject();
    const [value,setvalue]=useState();
            React.useEffect(() => {
              $(document).on('input', '#1', function () {
                $.post("http://0.0.0.0:5000/api/lights", {
                  ex1: { value: $(this).val() }
                });
              });
                $(document).on('input', '#2', function () {
                  $.post("http://0.0.0.0:5000/api/lights", {
                    ex2: { value: $(this).val() }
                  });
                });
                $(document).on('input', '#3', function () {
                  $.post("http://0.0.0.0:5000/api/lights", {
                    ex3: { value: $(this).val() }
                  });
                });
              $(document).on('input', '#4', function () {
                $.post("http://0.0.0.0:5000/api/lights", {
                  ex4: { value: $(this).val() }
                });
              });
          });
    const handleRotete=async e=>{
      e.preventDefault();
      const token4 = await motor({
        ex5: {value:e.value}
      },"motor_cw");
    }
    const handleRotete1=async e=>{
      e.preventDefault();
      const token5 = await motor({
        ex5: {value:e.value}
      },"motor_ccw");
    }
    return (
      <>
        <div className="sidenav">
        <a href="#about">Project:<br />{project?project["name"]:<div></div>}</a>
        <a href="#about" value="motor_cw" onClick={handleRotete}><i class="fas fa-arrow-alt-circle-left fa-5x"></i></a>
        <a href="#services" value="motor_ccw" onClick={handleRotete1}><i class="fas fa-arrow-alt-circle-right fa-5x"></i></a>
        <form action="#">
        <p className="range-field">
          <input id="1" min={0}  max={100} type="range" value={value}  />
          </p>
          <p className="range-field">
          <input id="2" min={0}  max={100} type="range" value={value} />
          </p>
          
          <p className="range-field">
          <input id="3" min={0}  max={100} type="range" value={value} />
          </p>
          <p className="range-field">
          <input id="4" min={0}  max={100} type="range" value={value} />
          </p>
          </form>
      </div>
      
</>
    )
}
