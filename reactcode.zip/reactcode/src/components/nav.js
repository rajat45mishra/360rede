import React,{useState} from 'react'
import useToken from '../hooks/useToken'
import useFolder from '../hooks/useFolder'
import useProject from '../hooks/useProject'
import axios from 'axios'
import Form from './form'
import Popup from './default'

async function Project(credentials,token) {
	console.log(token);
    return fetch('http://0.0.0.0:5000/project/create/', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
		'Authorization' : token
      },
      body: JSON.stringify(credentials)
    })
      .then(data => data.json())
   }
export  function Nav() {
	const {token,setToken}=useToken();
	const {folder,setFolder}=useFolder();
  const [isOpen, setIsOpen] = useState(false);
	const [name, setName] = useState();
	const [seconds,setSeconds]=useState();
	const {project,setProject}=useProject();
	const togglePopup = () => {
		setIsOpen(!isOpen);	
	}
	
	const options = [
        '8 Seconds', '12 Seconds', '16 Seconds'
      ];
	  const handleSubmit = async e => {
		e.preventDefault();
		console.log(seconds)
		const token1 = await Project({
			"name": name,
			"time": seconds,
			"details": null
		},token);
		setProject(token1);
		console.log(project);
		togglePopup();
	  }
	const out='';
  const fetchData = async () => {
    const response = await axios.get(
      'http://0.0.0.0:5000/file/transformers/'
    );

    setFolder(response.data);
    if(!folder){
      const response = await axios.get(
        'http://0.0.0.0:5000/file/transformers/'
      );
      setFolder(response.data);
    }else if(!folder){
      const response = await axios.get(
        'http://0.0.0.0:5000/file/transformers/'
      );
  
      setFolder(response.data);
    }
  };
    return (
        <div>
           <nav>
				<div className="nav-wrapper" style={{backgroundColor:'#039be5'}}>
					<a href="/" className="brand-logo"><img src="https://tymui.herokuapp.com/static/img/logo.png" alt="img" style={{marginLeft:20,marginTop:10}}></img></a>
					<ul id="nav-mobile" className="right hide-on-med-and-down">
          <li><a onClick={togglePopup} href="#"><i class="fas fa-project-diagram"></i>Project</a></li>
						<li><a onClick={fetchData} href="/file"><i class="fas fa-file"></i> FileManager</a></li>
						{token? <li><a onClick={()=>{setToken(out)}}><i class="fas fa-sign-out-alt"></i> Signout</a></li>:<li><a href="/"><i class="fas fa-sign-in-alt"></i> SignIn</a></li>}
					</ul>
				</div>
			</nav> 
      {isOpen && <div style={{ marginTop: '60%' }}><Popup
								content={<>
									<b> Create Project</b>
									<div className="row">
										<form className="col s12" onSubmit={handleSubmit}>
											<div className="row">
												<div className="input-field col s6">
													<input placeholder="Project Name" id="first_name" type="text" className="validate" onChange={e=>setName(e.target.value)} />
												</div>

											</div>
											<p style={{display:'flex',alignItems:'center'}}>
												<h1 style={{fontSize:20,textAlign:'center'}}>Select Duration:</h1>
												<label style={{paddingRight:5}}>
													<Form options={options} setSeconds={setSeconds} title="seconds" />
												</label>
											</p>
											<div style={{ padding: '3%' }}>
									<button className="waves-effect waves-light btn-large" style={{backgroundColor:'#039be5',width:250}} type="submit">Create Project</button>
								</div>
										</form>
									</div></>}
								handleClose={togglePopup}
							/></div>}
        </div>
    )
}
