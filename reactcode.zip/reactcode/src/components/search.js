import React from 'react'
import Folders from './folders'
import useFolder from '../hooks/useFolder'
export default function Search() {
  const datad = String(new Date());
  const { folder, setFolder } = useFolder();
  const [searchTerm, setSearchTerm] = React.useState("");
  const [searchResults, setSearchResults] = React.useState([]);
  const handleChange = event => {
    setSearchTerm(event.target.value);
  };
  if(!folder){
      window.history.go(-1);
  }
  const datafordata = folder.projecttree
  React.useEffect(() => {
    const results = datafordata.filter(person =>
      person['projectname'].toLowerCase().includes(searchTerm)
    );
    setSearchResults(results);
  }, [searchTerm]);
  return (
    <>
      <div style={{ paddingTop: 100, paddingLeft: '34%' }}>
        <div className="row">
          <div className="input-field col s6">
            <input id="first_name2" type="text" className="validate" placeholder="Search" value={searchTerm}
              onChange={handleChange} />
          </div>
        </div>
      </div>
      {
        searchResults.map((figure, key) => {
          return <Folders key={key} {...figure} />
        })
      }
    </>
  )
}
